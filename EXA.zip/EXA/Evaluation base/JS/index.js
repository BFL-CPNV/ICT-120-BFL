/*
Project : index.css
Author  : FARDEL Bastien
Date    : 15.11.2019
Version : 1.0
Description: css stylesheet for index.html
 */
var MyTimer = setInterval(Button_check, 10);

document.getElementById("fname").addEventListener("change", Check_fname);
document.getElementById("lname").addEventListener("change", Check_lname);
document.getElementById("psw").addEventListener("change", Check_password);
document.getElementById("confirm").addEventListener("change", Confirm_password);

function Check_fname()
{
    var name = document.getElementById("fname");
    var fname = name.value;

    if (fname.length < 3 || fname === ""){
        document.getElementById("invalid_fname").setAttribute("class", "invalid");
    }
    else {
        document.getElementById("invalid_fname").setAttribute("class", "hide");
    }
}

function Check_lname()
{
    var name = document.getElementById("lname");
    var lname = name.value;

    if (lname.length < 3 || lname === ""){
        document.getElementById("invalid_lname").setAttribute("class", "invalid");
    }
    else {
        document.getElementById("invalid_lname").setAttribute("class", "hide");
    }
}

function Check_password()
{
    var psw = document.getElementById("psw");
    var password = psw.value;

    if (password.length <= 6 || password === ""){
        document.getElementById("invalid_psw").setAttribute("class", "invalid");
    }
    else {
        document.getElementById("invalid_psw").setAttribute("class", "hide");
    }
}

function Confirm_password()
{
    var psw = document.getElementById("psw");
    var password = psw.value;
    var y = document.getElementById("confirm");
    var confirm = y.value;

    if (confirm === password){
        document.getElementById("invalid_confirm").setAttribute("class", "hide");
    }
    else {
        document.getElementById("invalid_confirm").setAttribute("class", "invalid");
    }
}

function Button_check(){
    var name = document.getElementById("fname");
    var fname = name.value;

    var name = document.getElementById("lname");
    var lname = name.value;

    var psw = document.getElementById("psw");
    var password = psw.value;

    var y = document.getElementById("confirm");
    var confirm = y.value;

    if (fname.length < 3 || fname === "" || lname.length < 3 || lname === "" || password.length <= 6 || password === "" || confirm === password){ // Small bug, the buttons isn't enabled if the confirm is correct and I don't know why that is.
        document.getElementById("send").setAttribute("class", "disabled");
        document.getElementById("send").setAttribute("disabled","");
    }
    else {
        document.getElementById("send").setAttribute("class", "enabled");
        document.getElementById("send").setAttribute("disabled", "false"); // It also appears that the button even if enabled, doesn't submit to the other page.
    }


}